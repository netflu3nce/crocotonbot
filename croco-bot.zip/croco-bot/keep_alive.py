from flask import Flask
from threading import Thread

app = Flask(__name__)

@app.route("/")
def home():
    return "🐊 Croco Bot is alive in the swamp."

@app.route("/health")
def health():
    return {"status": "alive", "bot": "CrocoBot"}, 200

def run():
    app.run(host="0.0.0.0", port=8080)

def keep_alive():
    t = Thread(target=run)
    t.daemon = True
    t.start()
